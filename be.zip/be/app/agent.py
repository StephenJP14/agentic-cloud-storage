import os
import json
from typing import TypedDict, Literal, Annotated
from dotenv import load_dotenv

from langgraph.checkpoint.redis import RedisSaver
from langchain_ollama import ChatOllama
from qdrant_client import QdrantClient
from qdrant_client.http import models

from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage, BaseMessage
from langchain_core.tools import tool
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.documents import Document

from pydantic import BaseModel, Field
from .embed_model import get_embed_model
from langchain_community.document_compressors.flashrank_rerank import FlashrankRerank

load_dotenv()
WINDOWS_IP = os.getenv("WINDOWS_IP", "127.0.0.1")
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", f"http://{WINDOWS_IP}:11434")
QDRANT_URL = os.getenv("QDRANT_URL", f"http://{WINDOWS_IP}:6333")
REDIS_URL = os.getenv("REDIS_URL", f"redis://{WINDOWS_IP}:6379")

client = QdrantClient(url=QDRANT_URL)
collection_name = "user_docs"

# print("Memuat BGE-M3 Model...")

compressor = FlashrankRerank(model="ms-marco-MiniLM-L-12-v2", top_n=3)
llm = ChatOllama(
    base_url=OLLAMA_URL, 
    model="qwen3-vl:8b-instruct", 
    temperature=0.1,
    num_ctx=8192
    )

class RouteQuery(BaseModel):
    datasource: Literal["vectorstore", "chitchat"] = Field(..., description="Route target")

router_prompt = ChatPromptTemplate.from_messages([
    ("system", "Berdasarkan pertanyaan user, tentukan routing. Jika butuh baca file/materi kuliah, pilih 'vectorstore'. Jika sapaan biasa, 'chitchat'."),
    ("human", "{question}"),
])
router_chain = router_prompt | llm.with_structured_output(RouteQuery)

# [MODIFIED] Tambahkan revision_count untuk mencegah infinite loop di LangGraph
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    context: str
    file_url: str
    revision_count: int 

def get_history_text(messages):
    return "\n".join([f"{'User' if isinstance(m, HumanMessage) else 'AI'}: {m.content}" for m in messages[-4:]])

def router_node(state: AgentState):
    last_message = state["messages"][-1].content
    try:
        decision = router_chain.invoke({"question": last_message}).datasource
    except:
        decision = "chitchat"
    return {"context": decision}

def search_node(state: AgentState):
    embed_model = get_embed_model() 

    messages = state["messages"]
    original_query = messages[-1].content
    history_text = get_history_text(messages[:-1]) 
    
    print(f"\n🔍 [QUERY] User bertanya: '{original_query}'")

    hyde_prompt = f"""Sebagai asisten akademik, buatlah 1 paragraf penjelasan/tebakan akademis untuk pertanyaan berikut.
    Pertanyaan User: '{original_query}'
    Konteks Chat: {history_text}
    ATURAN KRUSIAL: Tulis langsung tanpa pengantar."""
    
    hyde_query = llm.invoke(hyde_prompt).content
    print(f"🧠 [HyDE] Hipotesis Akademik: '{hyde_query}'")

    search_query = f"{original_query} {hyde_query}"

    query_embeddings = embed_model.encode(search_query, return_dense=True, return_sparse=True)
    dense_vec = query_embeddings['dense_vecs'].tolist()
    lexical_weights = query_embeddings['lexical_weights']
    
    tokens = list(lexical_weights.keys())
    weights = list(lexical_weights.values())
    token_ids = embed_model.tokenizer.convert_tokens_to_ids(tokens)
    
    dedup_sparse = {}
    for idx, w in zip(token_ids, weights):
        if idx not in dedup_sparse or w > dedup_sparse[idx]:
            dedup_sparse[idx] = w
    
    final_indices = list(dedup_sparse.keys())
    final_values = list(dedup_sparse.values())

    sparse_vector = models.SparseVector(
        indices=final_indices,
        values=final_values
    )

    print(f"📡 [RETRIEVAL] Menjalankan Hybrid Search (RRF) di Qdrant...")
    raw_results = client.query_points(
        collection_name=collection_name,
        prefetch=[
            models.Prefetch(query=dense_vec, using="", limit=10),
            models.Prefetch(query=sparse_vector, using="sparse", limit=10),
        ],
        query=models.FusionQuery(fusion=models.Fusion.RRF),
        limit=10,
        with_payload=True
    ).points

    retrieved_docs = [
        Document(page_content=point.payload["text"], metadata=point.payload)
        for point in raw_results
    ]

    reranked_docs = compressor.compress_documents(documents=retrieved_docs, query=search_query)

    if not reranked_docs:
        print("⚠️ [RESULT] Tidak ditemukan dokumen relevan.")
        return {"messages": [SystemMessage(content="No relevant academic docs found.")], "file_url": ""}

    print(f"✨ [RESULT] Menemukan {len(raw_results)} chunk relevan.")
    print("Contoh chunk:\n", retrieved_docs[0].page_content)
    
    # [MODIFIED] Inject parameter [TIPE: ...] agar AI membedakan teks vs gambar
    formatted_docs = []
    for doc in reranked_docs:
        text = doc.page_content
        filename = doc.metadata.get("filename", "Unknown File")
        page_num = doc.metadata.get("page_number", "?")
        source_type = doc.metadata.get("source_type", "text_paragraph")
        formatted_docs.append(f"[NAMA FILE: {filename}] [HALAMAN: {page_num}] [TIPE: {source_type}]\n{text}")

    content = "\n\n====================\n\n".join(formatted_docs)
    source_url = reranked_docs[0].metadata.get("file_url", "Unknown Link") 

    return {
        "messages": [SystemMessage(content=f"DOCUMENT CONTEXT:\n{content}")],
        "file_url": source_url 
    }

class Citation(BaseModel):
    exact_quote: str = Field(description="Kutipan persis dari dokumen yang mendukung kalimat Anda.")
    page_number: str = Field(description="Nomor halaman dari referensi.")
    filename: str = Field(description="Nama file dokumen sumber referensi.")

class AnswerWithSources(BaseModel):
    answer: str = Field(description="Jawaban utama Anda. Gunakan penanda seperti [1] jika merujuk ke citation di bawah.")
    citations: list[Citation] = Field(description="Daftar referensi yang Anda ekstrak dari dokumen.")

def answer_node(state: AgentState):
    messages = state["messages"]
    
    # Mencari Konteks Dokumen dari History (Karena bisa tergeser oleh pesan Kritik)
    doc_context = ""
    for m in reversed(messages):
        if isinstance(m, SystemMessage) and "DOCUMENT CONTEXT" in m.content:
            doc_context = m.content
            break

    if doc_context:
        # Mencari pertanyaan asli user
        user_question = "Jelaskan."
        for m in messages:
            if isinstance(m, HumanMessage) and not m.content.startswith("Kritik Agen Verifikator:"):
                user_question = m.content

        # [MODIFIED] Mencari apakah ada perintah revisi dari Critic Node
        critic_feedback = ""
        if isinstance(messages[-1], HumanMessage) and messages[-1].content.startswith("Kritik Agen Verifikator:"):
            critic_feedback = f"\n\n🚨 PENTING - REVISI DRAF ANDA BERDASARKAN KRITIK INI:\n{messages[-1].content}"
        
        structured_llm = llm.with_structured_output(AnswerWithSources)
        
        rag_prompt = f"""Anda asisten akademik. Jawab pertanyaan berdasarkan DOKUMEN di bawah.
        1. Jawab pertanyaan dengan baik. Akhiri kalimat yang merujuk pada dokumen dengan angka referensi, misal [1].
        2. Ekstrak kutipan kalimat ASLI secara persis dari teks.
        3. Perhatikan label [TIPE: text_paragraph] vs [TIPE: image_ocr]. Satukan perspektif keduanya.
        {critic_feedback}
        
        PERTANYAAN: "{user_question}"
        
        DOKUMEN:
        {doc_context}
        """
        
        try:
            response_obj = structured_llm.invoke([HumanMessage(content=rag_prompt)])
            json_result = response_obj.model_dump_json()
            return {"messages": [AIMessage(content=json_result)]}
        except Exception as e:
            print("Structured output error:", e)
            return {"messages": [AIMessage(content=f'{{"answer": "Maaf, terjadi kesalahan saat memformat jawaban.", "citations": []}}')]}

    # Fallback untuk ChitChat
    response = llm.invoke(messages)
    chitchat_json = json.dumps({"answer": response.content, "citations": []})
    return {"messages": [AIMessage(content=chitchat_json)]}

# ==========================================
# [NEW] CRITIC NODE (AGEN VERIFIKATOR)
# ==========================================
class CriticDecision(BaseModel):
    status: Literal["APPROVE", "REJECT"] = Field(description="APPROVE jika jawaban lengkap, REJECT jika ada info penting dari dokumen yang terlewat.")
    feedback: str = Field(description="Jika REJECT, beri tahu spesifik apa yang terlewat (misal: 'Anda lupa menyebutkan pilar ke-4 di gambar'). Jika APPROVE, isi 'OK'.")

def critic_node(state: AgentState):
    print("🕵️‍♂️ [CRITIC] Mengevaluasi draf jawaban...")
    messages = state["messages"]
    last_message = messages[-1].content

    # Cek apakah ini mode RAG atau ChitChat
    doc_context = ""
    for m in reversed(messages):
        if isinstance(m, SystemMessage) and "DOCUMENT CONTEXT" in m.content:
            doc_context = m.content
            break

    if not doc_context:
        return {"revision_count": state.get("revision_count", 0)}

    # Ekstrak jawaban teks dari output JSON draf
    try:
        draft_json = json.loads(last_message)
        draft_answer = draft_json.get("answer", last_message)
    except:
        draft_answer = last_message

    critic_prompt = f"""Anda adalah Agen Verifikator Akademik (Critic).
    Tugas Anda: Membandingkan DRAF JAWABAN dengan DOKUMEN SUMBER.

    DOKUMEN SUMBER (Mengandung Teks & Ekstraksi Gambar):
    {doc_context}

    DRAF JAWABAN SEMENTARA:
    {draft_answer}

    ANALISIS:
    Apakah draf jawaban ini sudah merangkum semua sisi dari konteks? Apakah ada bagian dari dokumen (seperti deskripsi [TIPE: image_ocr]) yang bertentangan atau terlewatkan dari draf ini?
    Jika terdeteksi ada yang terlewat, tolak (REJECT) dan sebutkan detailnya.
    """

    try:
        decision = llm.with_structured_output(CriticDecision).invoke([HumanMessage(content=critic_prompt)])
    except Exception as e:
        print(f"⚠️ [CRITIC] Error saat validasi: {e}. Defaulting to APPROVE.")
        decision = CriticDecision(status="APPROVE", feedback="OK")

    print(f"🕵️‍♂️ [CRITIC] Status: {decision.status} | Feedback: {decision.feedback}")

    rev_count = state.get("revision_count", 0) + 1

    # Maksimal revisi dibatasi 2 kali untuk mencegah AI terjebak infinite loop (terus-menerus REJECT)
    if decision.status == "REJECT" and rev_count <= 2:
        return {
            "messages": [HumanMessage(content=f"Kritik Agen Verifikator: {decision.feedback}. Lakukan revisi!")],
            "revision_count": rev_count
        }
    else:
        return {"revision_count": rev_count} # Lolos evaluasi / batas revisi habis

# ==========================================
# GRAPH ROUTING
# ==========================================
workflow = StateGraph(AgentState)
workflow.add_node("router", router_node)
workflow.add_node("search", search_node)
workflow.add_node("generate", answer_node) 
workflow.add_node("critic", critic_node) # [NEW] Daftarkan node
workflow.set_entry_point("router")

def route_logic(state):
    return "search" if state["context"] == "vectorstore" else "generate"

# [NEW] Logika rute untuk Critic Node (Kembali ke generate jika ditolak)
def critic_router(state):
    messages = state.get("messages", [])
    if messages and isinstance(messages[-1], HumanMessage) and "Kritik Agen Verifikator" in messages[-1].content:
        print("🔄 [WORKFLOW] Mengirim draf kembali ke Generator untuk direvisi...")
        return "generate"
    print("✅ [WORKFLOW] Draf disetujui, menyajikan jawaban akhir ke User.")
    return "end"

workflow.add_conditional_edges("router", route_logic, {"search": "search", "generate": "generate"})
workflow.add_edge("search", "generate")
workflow.add_edge("generate", "critic") # Setelah generate, kirim ke critic
workflow.add_conditional_edges("critic", critic_router, {"generate": "generate", "end": END})

def get_graph_workflow():
    return workflow